
<body>

<?php
 
 $sName =$_POST["sname"];
 $password =$_POST["Password"];
$passwordRetype =$_POST["retype_Password"];
$email =$_POST["Email"];
$phone =$_POST["phone"];
$comments =$_POST["comments"];
$AnimalList =$_POST["animal_list"];

 
 
 
 if(!empty ($password && $sName && $email && $phone && $AnimalList )){
	 echo"Name: $password <br>";
	echo"Username: $sName <br> ";
	echo"Email: $email <br>";
	echo"Phone: $phone <br>";
	echo"Animal List: $AnimalList<br>";
	
	  
	}else{
		echo" please fill in all the values";
	}
	  ?>
	