<!DOCTYPE html>
<html>
<head>
<title>vet form</title>
<link rel="stylesheet" href="formCss.css">
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.css">
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap-theme.css">

</head>
<body>
	<div id="myform">
	<div id="header">
	<h1> Vertinary form</h1>
	<p>if you have no account sign in if you have an account login below</p>
	</div>
	<form action="formShown.php" method="post" enctype="multipart/form-data" id="">
		<fieldset><br>
			<legend>Sign In Form</legend>
		<fieldset>
			<legend>User Name</legend>
			<input type="text" id="form_username" name="sname" ><span id="username_error_message" required></span>
			<legend>Password</legend>
			<input type="password" id="form_password" name="Password" required >
			<legend>Password Retype</legend>
			<input type="password" id="form_retry_password" name="retype_Password" ><span id="retype_password_error_message" required></span>
			<legend>Email</legend>
			<input type="email" id="form_mail" name="Email" ><span id="email_error_message"></span>
			<legend>Phone</legend>
			<input type="tel" id="form_phone" name="phone" >
			<figcaption>Enter you Address</figcaption>
					<textarea name="comments" cols="10" rows="5" maxlength="500"></textarea><br>
		</fieldset>
		<fieldset><br><br>
			
			<legend>Select Animal</legend>
				<select name="animal_list" id="animal_list" >
					<option name="dogs" id="dogs">Dogs</option>
					<option name="cat" id="cat">Cats</option>
					<option name="cattle" id="cattle">Cattle</option>
					<option name="bird" id="bird">Birds</option>
					<option name="fish" id="fish">Fish</option>
					<option name="sheep" id="sheep">Sheeps</option>
					<option name="dogs" id="dogs"></option></select><br><br>
		
			</fieldset><br>
			<input type="reset" name="Reset" id="Reset" value="reset">
			<input type="submit" id="submit" name="submit" value="singIn">
		</fieldset>
		</form>
	</div><br><br>

	<div id="login">
	
		<form action="logged.php" method="post">
		<legend>Login </legend>
		
			<label for="username" > Username</label>
			<input type="text" name="username">

			<label for="password" >password</label>
			<input type="password" name="password"><br>
			<input type="submit" value="login">
			</fieldset>

         </form>
	</div>
</body>
<script src="jquery-2.2.0.js"></script>
<script src="project_form.js"></script>
</html>