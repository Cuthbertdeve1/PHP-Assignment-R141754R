<html>

<?php
echo"welcome ".( $_GET['username']);

?>
<body>

	<h1> This is Your Account man!!</h1>
	<h2>I love Programming</h2>
</body>
</html>