<?php
 
 
 if($_POST['username']=='cuthbert' && $_POST['password']=='1234'){
	 
	 ?>
	 <a href="profile.php?username=<?php echo $_POST['username']?>">
	 go to profile page
	 </a>
	 <?php
 }
else{
	?>
		<a href="index.php">log in failure go back to Vetinary Form </a>
		<?php
}

?>